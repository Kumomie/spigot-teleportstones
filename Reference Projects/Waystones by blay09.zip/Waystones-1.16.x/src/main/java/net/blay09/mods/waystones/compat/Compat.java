package net.blay09.mods.waystones.compat;

public class Compat {

	public static final String THEONEPROBE = "theoneprobe";

}
