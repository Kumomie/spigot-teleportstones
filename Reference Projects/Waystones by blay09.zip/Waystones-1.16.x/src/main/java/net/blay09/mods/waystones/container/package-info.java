@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
package net.blay09.mods.waystones.container;

import mcp.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;
