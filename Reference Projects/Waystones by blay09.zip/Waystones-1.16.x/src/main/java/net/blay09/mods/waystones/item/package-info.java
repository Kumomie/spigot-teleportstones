@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
package net.blay09.mods.waystones.item;

import mcp.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;