package net.blay09.mods.waystones.api;

public interface IResetUseOnDamage {
}
