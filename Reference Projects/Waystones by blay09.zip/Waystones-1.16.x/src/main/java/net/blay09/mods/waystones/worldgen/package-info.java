@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
package net.blay09.mods.waystones.worldgen;

import mcp.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;