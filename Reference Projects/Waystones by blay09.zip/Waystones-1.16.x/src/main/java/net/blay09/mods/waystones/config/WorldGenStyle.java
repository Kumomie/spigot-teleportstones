package net.blay09.mods.waystones.config;

public enum WorldGenStyle {
    DEFAULT,
    MOSSY,
    SANDY,
    BIOME
}
