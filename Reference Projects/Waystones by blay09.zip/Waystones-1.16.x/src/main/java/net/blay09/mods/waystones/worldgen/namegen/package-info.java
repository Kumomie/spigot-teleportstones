@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
package net.blay09.mods.waystones.worldgen.namegen;

import mcp.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;
