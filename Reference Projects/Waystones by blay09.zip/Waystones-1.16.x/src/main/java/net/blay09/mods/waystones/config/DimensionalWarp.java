package net.blay09.mods.waystones.config;

public enum DimensionalWarp {
    ALLOW,
    GLOBAL_ONLY,
    DENY
}
