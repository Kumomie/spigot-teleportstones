package net.blay09.mods.waystones.worldgen.namegen;

public enum NameGenerationMode {
    PRESET_FIRST,
    RANDOM_ONLY,
    PRESET_ONLY,
    MIXED
}
