@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
package net.blay09.mods.waystones.network.message;

import mcp.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;