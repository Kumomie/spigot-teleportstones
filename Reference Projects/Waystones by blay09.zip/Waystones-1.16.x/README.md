# Waystones
Minecraft Mod. Teleport back to activated waystones. For Survival, Adventure or Servers.

[![Versions](http://cf.way2muchnoise.eu/versions/waystones.svg)](https://minecraft.curseforge.com/projects/waystones) [![Downloads](http://cf.way2muchnoise.eu/full_waystones_downloads.svg)](https://minecraft.curseforge.com/projects/waystones)