---
name: Request a Feature
about: Note that new features are only added to the latest Minecraft version.
title: ''
labels: feature
assignees: ''

---


